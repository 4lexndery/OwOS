import subprocess, platform, getpass

def cls():
    if platform.system == 'Windows':
        subprocess.run('cls',shell=True)
    else:
        subprocess.run('clear',shell=True)

while True:
    with open('pswd.pass','r') as f:
        userc = getpass.getpass('Enter your password: ')
        if userc in f:
            print('Opening Home')
            break
        else:
            print('Wrong password')
subprocess.run('python home.py',shell=True)        
