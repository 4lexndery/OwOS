import time, random, subprocess, platform

def cls():
    if platform.system == 'Windows':
        subprocess.run('cls',shell=True)
    else:
        subprocess.run('clear',shell=True)

user = open('user.pass').read()

cls()
print("Hello, "+user+
"""

--------

\033[1;40;35mWelcome To\033[1;40;37m
  ooo  \033[1;40;35mw  w  w  \033[1;40;37mooo   \033[1;40;35msss
\033[1;40;37m o   o \033[1;40;35mw  w  w \033[1;40;37mo   o \033[1;40;35ms   
\033[1;40;37m o   o \033[1;40;35mw  w  w \033[1;40;37mo   o  \033[1;40;35msss
\033[1;40;37m o   o \033[1;40;35mw  w  w \033[1;40;37mo   o     \033[1;40;35ms
\033[1;40;37m  ooo   \033[1;40;35mww ww   \033[1;40;37mooo   \033[1;40;35msss\033[0;40;37m
""")

while True:
    owo = input("""<1> Date & Time
<2> About OwOS
<3> Exit
------------
\033[3;40;37m<?\033[2;40;37mo\033[2;40;35mw\033[2;40;37mo\033[0;40;37m\033[3;40;37m?>\033[0;40;37m """)
    if owo == '1':
        print(f"""
date & time: \033[1;40;35m{time.strftime("%d-%h-%Y / %H:%M:%S")}\033[1;40;37m
        """)
        time.sleep(5)
        cls()
    elif owo == '2':
        cls()
        print("""
name: '\033[1;40;35mO\033[1;40;37mw\033[1;40;35mOS\033[1;40;37m 8\033[1;40;35m.\033[1;40;37m22\033[0;40;37m'
description: \033[1;40;37m'A command-line OS (Operating System) created with \033[1;40;35mpython\033[0;40;37m'
release date: '\033[1;40;35mFriday, August 26th 2022\033[0;40;37m'
""")
        time.sleep(10)
        cls()
    elif owo == '3':
        byes = [
            'Goodbye',
            'Bye',
            'Sayonara',
            'adiós',
            'Paalam',
            'Arrivederci',
            'Au revoir',
            'Vale',
            'Farvel',
            'Adjö',
            'Tot ziens',
            'Tạm biệt'
        ]
        user = open('user.pass').read()
        while True:
            yn = input(f'Owo you sure {user}? ')
            if yn.lower() == 'yes':
                g = True
                break
            elif yn.lower() == 'no':
                g = False
                cls()
                break
            else:
                print('Invalid answer')
        if g == True:
            print(f"""
{random.choice(byes)}
""")
            time.sleep(1)
            cls()
            print('\nMade by alec#8712 from discord\n')
            time.sleep(1)
            cls()
            break
    else:
        print("""
Invalid Argument OWO
        """)
