import subprocess, platform

def cls():
    if platform.system == 'Windows':
        subprocess.run('cls',shell=True)
    else:
        subprocess.run('clear',shell=True)

with open('info.data','w') as f:
    f.write('1')

with open('user.pass','w') as u:
    user = input('Enter your username: ')
    u.write(user)

with open('pswd.pass','w') as p:
    pswd = input('Enter your password: ')
    p.write(pswd)

print('Opening Home')
subprocess.run('python home.py',shell=True)
