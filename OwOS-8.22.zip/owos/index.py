import subprocess, platform

def cls():
    if platform.system == 'Windows':
        subprocess.run('cls',shell=True)
    else:
        subprocess.run('clear',shell=True)

with open('info.data') as f:
    if '1' in f:
        print('Opening Login')
        subprocess.run('python login.py',shell=True)
    else:
        print('Opening Setup')
        subprocess.run('python setup.py',shell=True)
